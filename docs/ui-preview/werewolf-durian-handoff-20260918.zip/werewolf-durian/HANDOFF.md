# 狼人杀 / 榴莲 UI 接手说明

更新：2026-09-18。项目：`D:\项目`。先读本文件，再读 `DESIGN.md`；`NEXT-AGENT-PROMPT.md` 可作为接手提示词。

## 当前阶段与边界

当前交付是独立、固定数据、可直接打开的 HTML 原型；不是正式 React 实现，也没有接入真实对局。用户要求先看效果，再确认正式开发。不要擅自将候选设计系统全量替换到生产项目。

用户最后明确要求：按照当前最新一版效果接手，不存在额外的 B 方案。榴莲大数字为 Georgia 衬线数字，小字保持普通字体，落实于 `durian-cards.css`。以最新 HTML 为视觉基准；这不等于已经授权全项目替换或正式接入。

用户已纠正：“按照目前最新一版的这个效果即可，没有B方案。”不要再追问 B，也不要另行制作 B。最新榴莲默认紧凑总览、回合弹窗及 Georgia 大数字；狼人杀最新页默认为 refined 优化版 + woodcut 木刻主题。HTML 内其他主题只是历史对比选项，不是本次接手要求。

## 从哪里看当前效果

| 文件 | 地位 |
| --- | --- |
| `durian.html` | 最新榴莲个人操作端；默认回合弹窗，收起看桌面 |
| `art-directions.html` | 最新狼人杀左右席位候选；A 木刻 / B 月蚀 / C 赤幕；顶部可选优化版与上一版 |
| `design-v2.html` | 设计语言候选说明和浅色/深色组件示例，不是全项目已采用规范 |
| `index.html` | 原双游戏预览入口；其中狼人杀 iframe 仍是早期 `werewolf.html`，不要误当最新狼人杀定稿 |
| `werewolf.html` | 较早的完整白天/夜晚/投票交互参考 |
| `werewolf-art.*`、`screenshots/` | 目录现有资料；本次交接未核验其版本，不视为当前视觉基准 |

原型必须连同 CSS、JS、assets 一起复制，不能只传一个 HTML。纯本地资源，无需安装框架。已有 `docs/design-preview.html` 保留。

## CSS 加载顺序就是当前实现依据

- 榴莲：`shared.css → durian.css → fusion.css → durian-fit.css → durian-turn.css → durian-cards.css`。
- 狼人杀最新候选：`art-directions.css → art-seating.css → art-platform.css → design-v2.css`；`data-design=refined` 为默认优化版。
- 覆盖层较多，这是迭代原型。正式实现前应归并为语义变量与组件样式，保持视觉和交互，不要继续无限叠补丁。

## 已有行为

榴莲：7 人固定示例，6 位他人牌公开，本人牌隐藏；需求统计；紧凑/舒展切换；自己的 draw/placement 阶段自动弹窗；收起不会提交或丢失选择；“继续我的回合”重新打开；确认出牌关闭弹窗；历史牌列；质疑结算；手动下一轮。预览工具默认收起到顶栏。两个密度选项都是真实的同一组 7 人示例，不是不同人数模式。

狼人杀最新艺术稿：左右各 6 人，中间发言者/倒计时/主题插画，底部操作；短横屏左右各两列。查看席位、私密身份、规则、票型、结束发言。艺术稿只演示发言场景；夜晚/投票完整交互仍在早期 `werewolf.html`。

## 必须诚实保留的验证边界

- 最近 `npm run typecheck` 已通过；榴莲规则与视图 10 项相关测试在上一轮行为修改后通过；这些测试不能证明原型弹窗和 CSS 正确。
- 最近字体修改仅改 CSS，随后类型检查通过。
- 历史上构建通过，有大 chunk 警告；不能说最新版原型完成了截图或设备验收。
- 最新多轮 CSS、回合弹窗、人数密度布局**没有完成浏览器视觉/E2E 复核**。之前浏览器工具拒绝 file URL，禁止用其他入口绕过该限制；新 Agent 应遵守自己环境的工具策略，不能伪造截图验证。
- 没有本轮启动的常驻预览服务器；不要关闭其他任务的 Node 进程。

## 建议下一步，按顺序

1. 读当前仓库 AGENTS.md、git status，保护大量既有未提交改动。原型目录目前也未提交，必须保存完整目录。
2. 在允许的环境检查 360×640、390×844、844×390、1280×800。检查 7 人长昵称、字体、数量、底部遮挡、横向溢出和弹层最大高度。超小窗口允许可访问的滚动兜底，不能靠 hidden 裁掉信息来假装一屏。
3. 冒烟回合流程：打开 → 收起 → 重新打开 → 选左右半边 → 再收起/返回确认选择仍在 → 确认只提交一次 → 等待；质疑 → 结果关闭/重开 → 下一轮自动打开摸牌。检查 ESC、遮罩关闭、键盘焦点和切场景不叠弹窗。
4. 先修原型具体问题并让用户看。用户确认第一批之后，才补法官端、榴莲公共桌面和朝外展示端；当前不应凭空报告五页已完成。
5. 正式接入前列出 HTML 与生产实现的差异，补真实协议、角色权限、生命周期、测试与构建；截图须用最终确认版本生成并标注尺寸/场景。

## 相关生产参考（只读理解，不自动覆盖）

- `packages/client/src/shared-ui/game-ui.css`：原平台 `--gp-*` 变量。
- `packages/client/src/game/werewolf/theatre.css`：现有暗夜主题。
- `packages/client/src/game/durian/DurianGamePage.tsx`、`durian.css`、`fruit-party.css`：现有榴莲业务/表现层。
- `packages/client/src/game/werewolf/`：狼人杀玩家/主持端。

## 检查命令

在 `D:\项目` 执行：

```powershell
node --check docs/ui-preview/werewolf-durian/durian.js
node --check docs/ui-preview/werewolf-durian/art-directions.js
npm run typecheck
node --import tsx --test packages/games/durian/tests/views.test.ts packages/games/durian/tests/rules.test.ts
```

正式接入按项目要求执行构建。直接 Vite 构建的正确工作目录为 `packages/client`，命令 `..\..\node_modules\.bin\vite.cmd build`；不要在根目录使用之前失败的 `npm exec vite build --prefix packages/client`。
